/* global bootstrap: false */
(function () {
  "use strict";
  var tooltipTriggerList = [].slice.call(
    document.querySelectorAll('[data-bs-toggle="tooltip"]')
  );
  tooltipTriggerList.forEach(function (tooltipTriggerEl) {
    new bootstrap.Tooltip(tooltipTriggerEl);
  });
})();
// ! For managing Teachers in Admin
const manageTeachersBtn = document.querySelector(".manage-teachers-btn"),
  manageTeachersForm = document.querySelector(".manage-teachers-form"),
  manageTeachersFormBody = manageTeachersForm.querySelector('tbody');

manageTeachersBtn?.addEventListener("click", () => {
  if (manageTeachersForm.classList.contains("shown")) {
    manageTeachersForm.classList.remove("shown");
  } else {
    manageTeachersForm.classList.add("shown");
    manageTeachersFormBody.innerHTML = "";
  }
});

// ! Login Component

const loginBtn = document.querySelector(".login-btn"),
  loginForm = document.querySelector(".login-form");

loginBtn?.addEventListener("click", () => {
  if (loginForm.classList.contains("shown")) {
    loginForm.classList.remove("shown");
  } else loginForm.classList.add("shown");
});

// ! Teacher Component
const addTeacherBtn = document.querySelector(".add-teacher-btn"),
  addTeacherForm = document.querySelector(".add-teacher-form");

addTeacherBtn?.addEventListener("click", () => {
  if (addTeacherForm.classList.contains("shown")) {
    addTeacherForm.classList.remove("shown");
  } else addTeacherForm.classList.add("shown");
});

// ! Announcement Component
const addAnnounceBtn = document.querySelector(".announce-btn"),
  announceForm = document.querySelector(".add-announcement-form");

addAnnounceBtn?.addEventListener("click", () => {
  let addAnnouncementForm = document.querySelector(
      ".add-announcement-form form"
    ),
    announcementHeader = addAnnouncementForm.querySelector("h1"),
    announcementExpiresAt = addAnnouncementForm.querySelector("#expiresAt"),
    announcementGradeSection = addAnnouncementForm.querySelector(
      ".add-announcement-gradesection"
    ),
    announcementTitle = addAnnouncementForm.querySelector(
      ".add-announcement-title"
    ),
    announcementContent = addAnnouncementForm.querySelector(
      ".add-announcement-content"
    ),
    announcementSubmitBtn = addAnnouncementForm.querySelector("button");
  if (announceForm.classList.contains("shown")) {
    announceForm.classList.remove("shown");
    announcementHeader.textContent = "Add An Announcement";
    announcementExpiresAt.value = "";
    announcementTitle.value = "";
    announcementContent.value = "";
    announcementGradeSection.value = localStorage.getItem("gradeSection");
    announcementSubmitBtn.textContent = "Add";
    if (
      addAnnouncementForm.action != "../src/Requests/Auth.php?action=announce"
    ) {
      addAnnouncementForm.action = `../src/Requests/Auth.php?action=announce`;
    }
  } else {
    announceForm.classList.add("shown");
  }
});

// ! Announcement
const manageBtn = document.querySelector(".manage-btn");

function compareDate(compareDate) {
  const currentDate = new Date();
  const parsedCompareDate = new Date(compareDate);
  return parsedCompareDate > currentDate;
}

const renderAnnouncement = (filter) => {
  if (manageBtn?.classList?.contains("btn-danger")) {
    manageBtn.click();
  }
  const announcementDiv = document.querySelector(".main-announcement");
  announcementDiv.innerHTML = "";
  fetch(`http://localhost/webdevfinal/src/Requests/Auth.php?filter=all`)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      data.map((announcement) => {
        let template = `
        <div class="card text-center announcement-card">
          <div class="card-header">${
            announcement.gradeSection != "All"
              ? announcement.gradeSection
              : "School Announcement"
          }</div>
            <div class="card-body announcement-body">
              <h5 class="card-title">${announcement.title}</h5>
              <p class="card-text announcement-content">${
                announcement.content
              }</p>
            </div>
          <div class="card-footer text-muted">Until: ${
            announcement.expiresAt
          }</div>
        </div>
        `;
        if (filter && compareDate(announcement.expiresAt)) {
          if (announcement.gradeSection == filter) {
            announcementDiv.insertAdjacentHTML("beforeend", template);
            return;
          }
        } else if (!filter && compareDate(announcement.expiresAt)) {
          announcementDiv.insertAdjacentHTML("beforeend", template);
          return;
        } else if (
          filter == "expired" &&
          !compareDate(announcement.expiresAt)
        ) {
          announcementDiv.insertAdjacentHTML("beforeend", template);
          return;
        } else if (filter == "All" && compareDate(announcement.expiresAt)) {
          announcementDiv.insertAdjacentHTML("beforeend", template);
          return;
        }
      });
    })
    .catch((error) => {
      console.error("Error:", error);
    });
};

renderAnnouncement();

const manageAnnouncement = (filter) => {
  const render = () => {
    const announcementDiv = document.querySelector(".main-announcement");
    announcementDiv.innerHTML = "";
    fetch(`http://localhost/webdevfinal/src/Requests/Auth.php?filter=all`)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        data.forEach((announcement) => {
          let template = `
            <div class="card text-center announcement-card">
              <input type="hidden" class="announcement-id" value="${
                announcement.id
              }">
              <div class="announcement-gradesection card-header">${
                announcement.gradeSection != "All"
                  ? announcement.gradeSection
                  : "School Announcement"
              }</div>
                <div class="card-body announcement-body">
                  <h5 class="card-title">${announcement.title}</h5>
                  <p class="card-text announcement-content">${
                    announcement.content
                  }</p>
                </div>
                <div class="manage-btns-div">
                <button type="button" class="edit-announcement-btn btn btn-primary" onclick="editAnnouncement(this)">Edit</button>
                <a href="http://localhost/webdevfinal/src/Requests/Auth.php?delete=${
                  announcement.id
                }" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this announcement?')">Delete</a>
                </div>
              <div class="card-footer text-muted">Until: <span class="announcement-expiry">${
                announcement.expiresAt
              }</span></div>
            </div>
            `;
          if (announcement.gradeSection == filter) {
            announcementDiv.insertAdjacentHTML("beforeend", template);
            return;
          } else if (filter == "admin") {
            announcementDiv.insertAdjacentHTML("beforeend", template);
            return;
          }
        });
      });
  };
  if (manageBtn.innerHTML == "Manage") {
    manageBtn.innerHTML = "X";
    manageBtn.classList.replace("btn-info", "btn-danger");
    render();
  } else {
    manageBtn.innerHTML = "Manage";
    manageBtn.classList.replace("btn-danger", "btn-info");
    renderAnnouncement();
  }
};

const editAnnouncement = (announcement) => {
  // ! Get edit details
  let announcementCard = announcement.closest(".announcement-card"),
    editAnnouncementId = announcementCard.querySelector(".announcement-id"),
    editAnnouncementGradeSection = announcementCard.querySelector(
      ".announcement-gradesection"
    ),
    editAnnouncementTitle = announcementCard.querySelector(
      ".announcement-body h5"
    ),
    editAnnouncementContent = announcementCard.querySelector(
      ".announcement-content"
    ),
    editAnnouncementExpiry = announcementCard.querySelector(
      ".announcement-expiry"
    );

  localStorage.setItem(
    "gradeSection",
    editAnnouncementGradeSection.textContent
  );
  // ! Get Add Announcement Variables
  let addAnnouncementForm = document.querySelector(
      ".add-announcement-form form"
    ),
    announcementHeader = addAnnouncementForm.querySelector("h1"),
    announcementExpiresAt = addAnnouncementForm.querySelector("#expiresAt"),
    announcementGradeSection = addAnnouncementForm.querySelector(
      ".add-announcement-gradesection"
    ),
    announcementTitle = addAnnouncementForm.querySelector(
      ".add-announcement-title"
    ),
    announcementContent = addAnnouncementForm.querySelector(
      ".add-announcement-content"
    ),
    announcementSubmitBtn = addAnnouncementForm.querySelector("button");

  // ! Change Variables And Add Values
  announcementHeader.textContent = "Edit Announcement";
  announcementExpiresAt.value = editAnnouncementExpiry.textContent;
  announcementGradeSection.value =
    editAnnouncementGradeSection.textContent == "School Announcement"
      ? "All"
      : editAnnouncementGradeSection.textContent;
  announcementTitle.value = editAnnouncementTitle.textContent;
  announcementContent.value = editAnnouncementContent.textContent;
  announcementSubmitBtn.textContent = "Edit";

  // ! Change Form Action
  addAnnouncementForm.action = `../src/Requests/Auth.php?edit=${editAnnouncementId.value}`;
  addAnnounceBtn.click();
};
