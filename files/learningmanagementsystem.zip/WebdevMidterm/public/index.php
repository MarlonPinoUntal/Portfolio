<?php
include_once "../src/Requests/Auth.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.css" rel="stylesheet">
    <title>Webdev Final</title>
</head>

<body>
    <?php
    if (isset($_SESSION['login_message'])) {
        echo "<p class='login-message'>{$_SESSION['login_message']}</p>";
        unset($_SESSION['login_message']);
    }
    if (isset($_SESSION['add-teacher-state'])) {
        echo "<p class='add-teacher-state'>{$_SESSION['add-teacher-state']}</p>";
        unset($_SESSION['add-teacher-state']);
    }
    if (isset($_SESSION['add-announce-state'])) {
        echo "<p class='add-announce-state'>{$_SESSION['add-announce-state']}</p>";
        unset($_SESSION['add-announce-state']);
    }
    ?>
    <!-- // ! Manage Teachers Form  -->
    <div class="manage-teachers-form">
        <?php include_once '../src/Components/ManageTeachers.php'; ?>
    </div>
    <!-- //! Add Announcement Form -->
    <div class="add-announcement-form">
        <?php include_once "../src/Components/AddAnnouncement.php" ?>
    </div>
    <!-- // ! Add Teacher Form  -->
    <div class="add-teacher-form">
        <?php include_once "../src/Components/AddTeacher.php" ?>
    </div>
    <!-- // ! Login Form -->
    <div class="login-form">
        <?php include_once '../src/Components/Login.php' ?>
    </div>
    <!-- // ! Navigation Bar -->
    <?php include_once '../src/Components/NavigationBar.php' ?>

    <div class="main">
        <header class="fs-4 fw-semibold">
            <?php
            if (isset($_SESSION['user_logged_in'])) {
                echo "Welcome, " . $_SESSION['user_logged_in'];
                echo '<div class="actions">
                <button type="button" class="announce-btn btn btn-success" style="color: #fff; font-weight: 600;">Announce</button>
                <button type="button" class="manage-btn btn btn-info" style="color: #fff; font-weight: 600;" onclick="manageAnnouncement(\'' . $_SESSION["gradeSection"] . '\')">Manage</button>';
            } else {
                echo "Dashboard";
            }
            ?>
        </header>
        <div class="main-announcement">
        </div>
    </div>
    <script src="../bootstrap-5.0.2-dist/js/bootstrap.js" defer></script>
    <script src="index.js" defer></script>
</body>

</html>