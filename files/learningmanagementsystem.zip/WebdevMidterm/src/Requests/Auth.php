<?php
session_start();
function dbAuth($servername, $username, $password, $dbName)
{
    $conn = new mysqli($servername, $username, $password, $dbName);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        return false;
    }
    return $conn;
}

function loginAuth()
{
    $conn = dbAuth("localhost", "root", "", "webdev_midterm");
    $teacherId = $_POST['teacher-id'];
    $rawPassword = $_POST['teacher-password'];

    $statement = "SELECT teacherId, password, teacherName, gradeSection FROM teachers WHERE teacherId = ?";
    $stmt = $conn->prepare($statement);
    $stmt->bind_param("s", $teacherId);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($dbTeacherId, $hashedPassword, $teacherName, $gradeSection);
        $stmt->fetch();

        if ($rawPassword == $hashedPassword) {
            $_SESSION['user_logged_in'] = $teacherName;
            $_SESSION['gradeSection'] = $gradeSection;
            $_SESSION['login_message'] = "Login successful. Welcome, $teacherName!";
            header('Location: /webdevfinal/public/index.php');
        } else {
            header('Location: /webdevfinal/public/index.php');
            $_SESSION['login_message'] = "Login failed. Incorrect password.";
        }
    } else {
        $_SESSION['login_message'] = "Account not found.";
        header('Location: /webdevfinal/public/index.php');
    }
}

function logoutAuth()
{
    session_destroy();
    header('Location: /webdevfinal/public/index.php');
    exit;
}

if (isset($_GET['action'])) {
    $action = $_GET['action'];
    if ($action === 'logout') {
        logoutAuth();
    } elseif ($action === 'login') {
        loginAuth();
    } elseif ($action === 'addteacher') {
        insertTeacher();
    } elseif ($action === 'announce') {
        addAnnouncement();
    }
}

function fetchData()
{
    $conn = dbAuth("localhost", "root", "", "webdev_midterm");

    $sql = "SELECT * FROM announcements ORDER BY id DESC";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    // Execute the query
    if (!$stmt->execute()) {
        die("Error executing statement: " . $stmt->error);
    }

    // Get the result set
    $result = $stmt->get_result();

    $data = array();

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    $stmt->close();
    $conn->close();

    echo json_encode($data);
}


if (isset($_GET['filter'])) {
    $filter = $_GET['filter'];
    if ($filter == 'all') {
        fetchData();
    }
}

function insertTeacher()
{
    $teacherId = $_POST['add-teacher-id'];
    $teacherName = $_POST['add-teacher-name'];
    $gradeSection = $_POST['add-teacher-gradesection'];
    $password = $_POST['add-teacher-password'];

    $conn = dbAuth("localhost", "root", "", "webdev_midterm");

    $stmt = $conn->prepare("INSERT INTO `teachers`(`teacherId`, `teacherName`, `gradeSection`, `password`) VALUES (?, ?, ?, ?)");

    if (!$stmt) {
        die("Error in SQL statement: " . $conn->error);
        return false;
    }

    // Bind parameters
    $stmt->bind_param("ssss", $teacherId, $teacherName, $gradeSection, $password);

    // Execute the statement
    if ($stmt->execute()) {
        $stmt->close();
        $_SESSION['add-teacher-state'] = "Teacher Added Successfully!";
        header('Location: /webdevfinal/public/index.php');
        exit;
    } else {
        die("Error in execution: " . $stmt->error);
        return false;
    }
}

function addAnnouncement()
{
    $expiry = $_POST['add-announcement-expiry'];
    $gradeSection = $_POST['add-announcement-gradesection'];
    $title = $_POST['add-announcement-title'];
    $content = $_POST['add-announcement-content'];

    $conn = dbAuth("localhost", "root", "", "webdev_midterm");
    $stmt = "INSERT INTO `announcements`(`gradeSection`, `title`, `content`, `expiresAt`) VALUES ('$gradeSection', '$title', '$content','$expiry')";

    if ($conn->query($stmt)) {
        $_SESSION['add-announce-state'] = "Announcement Added Successfully!";
        header('Location: /webdevfinal/public/index.php');
        exit;
    } else {
        die("Error in execution: ");
        exit;
    }
}

function deleteAnnouncement($announcementId)
{
    $conn = dbAuth("localhost", "root", "", "webdev_midterm");
    $stmt = "DELETE FROM announcements WHERE id = $announcementId";
    if ($conn->query($stmt)) {
        $_SESSION['add-announce-state'] = "Announcement Deleted Successfully!";
        header('Location: /webdevfinal/public/index.php');
        exit;
    } else {
        die("Error in execution: ");
        exit;
    }
}

if (isset($_GET['delete'])) {
    $delete = $_GET['delete'];
    deleteAnnouncement($delete);
}


function editAnnouncement($id)
{
    $expiry = $_POST['add-announcement-expiry'];
    $gradeSection = $_POST['add-announcement-gradesection'];
    $title = $_POST['add-announcement-title'];
    $content = $_POST['add-announcement-content'];

    $conn = dbAuth("localhost", "root", "", "webdev_midterm");

    $stmt = "UPDATE `announcements` SET `title` = '$title', `content` = '$content', `expiresAt` = '$expiry', `gradeSection` = '$gradeSection' WHERE id = $id";

    if ($conn->query($stmt)) {
        $_SESSION['add-announce-state'] = "Announcement Edited Successfully!";
        header('Location: /webdevfinal/public/index.php');
        exit;
    } else {
        die("Error in execution: ");
        exit;
    }
}

if (isset($_GET['edit'])) {
    $edit = $_GET['edit'];
    editAnnouncement($edit);
}
