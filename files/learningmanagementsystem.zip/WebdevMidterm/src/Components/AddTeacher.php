<div class="add-teacher-form">
    <form class="form-signin" action="../src/Requests/Auth.php?action=addteacher" method="POST">
        <h1 class="h3 mb-3 font-weight-normal">Add A Teacher</h1>
        <input type="text" name="add-teacher-id" class="form-control" placeholder="Teacher ID" required autofocus maxlength="11">
        <input type="text" name="add-teacher-name" class="form-control" placeholder="Teacher Name" required autofocus>
        <input type="password" name="add-teacher-password" class="form-control" placeholder="Password" required>
        <select class="form-control" name="add-teacher-gradesection">
            <option value="Grade 7 Aquarius" selected>Grade 7 Aquarius</option>
            <option value="Grade 7 Gemini">Grade 7 Gemini</option>
            <option value="Grade 7 Pisces">Grade 7 Pisces</option>
            <option value="Grade 7 Aries">Grade 7 Aries</option>
            <option value="Grade 8 Carnation">Grade 8 Carnation</option>
            <option value="Grade 8 Rose">Grade 8 Rose</option>
            <option value="Grade 8 Chamomile">Grade 8 Chamomile</option>
            <option value="Grade 8 Daisy">Grade 8 Daisy</option>
            <option value="Grade 9 Aristotle">Grade 9 Aristotle</option>
            <option value="Grade 9 Galilei">Grade 9 Galilei</option>
            <option value="Grade 9 Newton">Grade 9 Newton</option>
            <option value="Grade 9 Darwin">Grade 9 Darwin</option>
            <option value="Grade 10 Hercules">Grade 10 Hercules</option>
            <option value="Grade 10 Apollo">Grade 10 Apollo</option>
            <option value="Grade 10 Artemis">Grade 10 Artemis</option>
            <option value="Grade 10 Aphrodite">Grade 10 Aphrodite</option>
        </select>
        <button class="btn btn-lg btn-primary btn-block w-100" type="submit">Add</button>
        <p class="mt-5 mb-3 text-muted">&copy; 2023</p>
    </form>
</div>