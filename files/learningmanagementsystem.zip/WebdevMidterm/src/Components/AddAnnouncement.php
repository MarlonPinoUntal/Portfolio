<form class="form-signin" action="../src/Requests/Auth.php?action=announce" method="POST">
    <h1 class="h3 mb-3 font-weight-normal">Add An Announcement</h1>
    <label for="expiresAt">Until:</label>
    <input type="date" class="form-control" id="expiresAt" name="add-announcement-expiry" required autofocus>
    <?php if (isset($_SESSION['gradeSection']) && $_SESSION['gradeSection'] == 'admin') {
        echo '<select class="add-announcement-gradesection form-control" name="add-announcement-gradesection">
    <option value="Grade 7 Aquarius" selected>Grade 7 Aquarius</option>
    <option value="Grade 7 Gemini">Grade 7 Gemini</option>
    <option value="Grade 7 Pisces">Grade 7 Pisces</option>
    <option value="Grade 7 Aries">Grade 7 Aries</option>
    <option value="Grade 8 Carnation">Grade 8 Carnation</option>
    <option value="Grade 8 Rose">Grade 8 Rose</option>
    <option value="Grade 8 Chamomile">Grade 8 Chamomile</option>
    <option value="Grade 8 Daisy">Grade 8 Daisy</option>
    <option value="Grade 9 Aristotle">Grade 9 Aristotle</option>
    <option value="Grade 9 Galilei">Grade 9 Galilei</option>
    <option value="Grade 9 Newton">Grade 9 Newton</option>
    <option value="Grade 9 Darwin">Grade 9 Darwin</option>
    <option value="Grade 10 Hercules">Grade 10 Hercules</option>
    <option value="Grade 10 Apollo">Grade 10 Apollo</option>
    <option value="Grade 10 Artemis">Grade 10 Artemis</option>
    <option value="Grade 10 Aphrodite">Grade 10 Aphrodite</option>
    <option value="All">School Announcement</option>
</select>';
    } else {
        echo '<input type="hidden" class="add-announcement-gradesection" name="add-announcement-gradesection" value="' . $_SESSION['gradeSection'] . '">';
    }
    ?>
    <input type="text" class="add-announcement-title form-control" name="add-announcement-title" placeholder="Announcement Title" required autofocus>
    <textarea placeholder="What would you like to announce?" name="add-announcement-content" class="form-control add-announcement-content" required autofocus></textarea>
    <button class="btn btn-lg btn-primary btn-block w-100" type="submit">Add</button>
    <p class="mt-5 mb-3 text-muted">&copy; 2023</p>
</form>