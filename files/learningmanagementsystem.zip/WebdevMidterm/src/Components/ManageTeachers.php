<table class="table border">
  <thead class="thead-dark">
    <tr>
      <th class="table-primary" scope="col">#</th>
      <th class="table-primary" scope="col">Teacher Id</th>
      <th class="table-primary" scope="col">Name</th>
      <th class="table-primary" scope="col">Grade And Section</th>
      <th class="table-primary" scope="col">Password</th>
    </tr>
  </thead>
  <tbody>
    
  </tbody>
</table>