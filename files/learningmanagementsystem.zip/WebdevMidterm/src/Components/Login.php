<form class="form-signin" action="../src/Requests/Auth.php?action=login" method="POST">
    <img class="mb-4" src="PNHS.jpg" alt="" width="72" height="72">
    <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
    <input type="text" name="teacher-id" id="inputEmail" class="form-control" placeholder="Teacher ID" required autofocus>
    <input type="password" name="teacher-password" id="inputPassword" class="form-control" placeholder="Password" required>
    <div class="checkbox mb-3">
        <label>
            <input type="checkbox" value="remember-me"> Remember me
        </label>
    </div>
    <button class="login-submit-btn btn btn-lg btn-primary btn-block w-100" type="submit">Sign in</button>
    <p class="mt-5 mb-3 text-muted">&copy; 2023</p>
</form>