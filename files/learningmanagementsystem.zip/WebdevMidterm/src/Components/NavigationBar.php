<div class="flex-shrink-0 p-3 bg-white border h-100" style="width: 280px; overflow-y: auto; position: fixed;">
    <a href="/webdevfinal/public" class="d-flex align-items-center pb-3 mb-3 link-dark text-decoration-none border-bottom">
        <img src="PNHS.jpg" alt="" style="height: 50px; width: 50px; margin: 0 10px; border-radius: 5px;">
        <span class="fs-5 fw-semibold">Pinamungajan NHS</span>
    </a>
    <ul class="list-unstyled ps-0">
        <li class="mb-1">
            <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#navigation-collapse" aria-expanded="true">
                Navigation
            </button>
            <div class="collapse show" id="navigation-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement()">Dashboard</a></li>
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement('expired')">Elapsed</a></li>
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement('All')">School Announcements</a></li>
                </ul>
            </div>
        </li>
        <li class="border-top my-3"></li>
        <li class="mb-1">
            <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#grade7-collapse" aria-expanded="false">
                Grade 7
            </button>
            <div class="collapse" id="grade7-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                    <li><a href="#" class="link-dark grade rounded" onclick="renderAnnouncement('Grade 7 Aquarius')">Aquarius</a></li>
                    <li><a href="#" class="link-dark grade rounded" onclick="renderAnnouncement('Grade 7 Gemini')">Gemini</a></li>
                    <li><a href="#" class="link-dark grade rounded" onclick="renderAnnouncement('Grade 7 Aries')">Aries</a></li>
                    <li><a href="#" class="link-dark grade rounded" onclick="renderAnnouncement('Grade 7 Pisces')">Pisces</a></li>
                </ul>
            </div>
        </li>
        <li class="mb-1">
            <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#grade8-collapse" aria-expanded="false">
                Grade 8
            </button>
            <div class="collapse" id="grade8-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                    <li><a href="#" class="link-dark grade rounded" onclick="renderAnnouncement('Grade 8 Carnation')">Carnation</a></li>
                    <li><a href="#" class="link-dark grade rounded" onclick="renderAnnouncement('Grade 8 Rose')">Rose</a></li>
                    <li><a href="#" class="link-dark grade rounded" onclick="renderAnnouncement('Grade 8 Chamomile')">Chamomile</a></li>
                    <li><a href="#" class="link-dark grade rounded" onclick="renderAnnouncement('Grade 8 Daisy')">Daisy</a></li>
                </ul>
            </div>
        </li>
        <li class="mb-1">
            <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#grade9-collapse" aria-expanded="false">
                Grade 9
            </button>
            <div class="collapse" id="grade9-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement('Grade 9 Aristotle')">Aristotle</a></li>
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement('Grade 9 Galilei')">Galilei</a></li>
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement('Grade 9 Newton')">Newton</a></li>
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement('Grade 9 Darwin')">Darwin</a></li>
                </ul>
            </div>
        </li>
        <li class="mb-1">
            <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#grade10-collapse" aria-expanded="false">
                Grade 10
            </button>
            <div class="collapse" id="grade10-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement('Grade 10 Hercules')">Hercules</a></li>
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement('Grade 10 Apollo')">Apollo</a></li>
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement('Grade 10 Artemis')">Artemis</a></li>
                    <li><a href="#" class="link-dark rounded" onclick="renderAnnouncement('Grade 10 Aphrodite')">Aphrodite</a></li>
                </ul>
            </div>
        </li>
        <li class="border-top my-3"></li>
        <li class="mb-1">
            <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#links-collapse" aria-expanded="false">
                Links
            </button>
            <div class="collapse" id="links-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                    <li><a href="#" class="link-dark rounded">Facebook</a></li>
                    <li><a href="#" class="link-dark rounded">Website</a></li>
                </ul>
            </div>
        </li>
        <li class="border-top my-3"></li>
        <li class="mb-1">
            <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#manage-collapse" aria-expanded="false">
                Manage
            </button>
            <div class="collapse" id="manage-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                    <?php
                    if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] == true) {
                        echo '<li><a href="../src/Requests/Auth.php?action=logout" class="logout-btn link-dark rounded">Logout</a></li>';
                        if ($_SESSION['gradeSection'] == 'admin') echo '<li><a href="#" class="add-teacher-btn link-dark rounded">Add A Teacher</a></li>';
                        if ($_SESSION['gradeSection'] == 'admin') echo '<li><a href="#" class="manage-teachers-btn link-dark rounded">Manage Teachers</a></li>';
                    } else {
                        echo '<li><a href="#" class="login-btn link-dark rounded">Login</a></li>';
                    }
                    ?>
                </ul>
            </div>
        </li>

    </ul>
</div>