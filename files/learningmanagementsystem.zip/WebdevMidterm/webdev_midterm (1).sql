-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2023 at 06:11 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webdev_midterm`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `gradeSection` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expiresAt` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `gradeSection`, `title`, `content`, `createdAt`, `expiresAt`) VALUES
(1, 'Grade 7 Aquarius', 'This is a Sample Title', 'This is a sample content for our webdev midterm so it doesnt have anything to do with the actual boring stuff ahh kapoy code.', '2023-10-08 09:47:10', '2023-10-10'),
(2, 'Grade 7 Aquarius', 'Important Announcement 1', 'This is the content for announcement 1.', '2023-10-07 16:00:00', '2023-10-15'),
(3, 'Grade 7 Gemini', 'Upcoming Event', 'Details about the event happening next week.', '2023-10-07 16:00:00', '2023-10-20'),
(4, 'Grade 7 Aries', 'School News', 'Latest news about school activities.', '2023-10-07 16:00:00', '2023-10-15'),
(5, 'Grade 7 Pisces', 'Reminder: Parent-Teacher Meeting', 'Dont forget the meeting on October 12th.', '2023-10-07 16:00:00', '2023-10-13'),
(6, 'Grade 7 Aquarius', 'Important Announcement 2', 'This is the content for announcement 2.', '2023-10-07 16:00:00', '2023-10-15'),
(7, 'Grade 7 Aries', 'Science Fair', 'Details about the upcoming science fair.', '2023-10-07 16:00:00', '2023-10-17'),
(8, 'Grade 7 Pisces', 'Art Exhibition', 'Information about the upcoming art exhibition.', '2023-10-07 16:00:00', '2023-10-22'),
(9, 'Grade 7 Gemini', 'Sports Day', 'Get ready for the annual sports day!', '2023-10-07 16:00:00', '2023-10-19'),
(10, 'Grade 7 Aquarius', 'Holiday Schedule', 'Check the schedule for the upcoming holidays.', '2023-10-07 16:00:00', '2023-10-12'),
(11, 'Grade 7 Gemini', 'Exam Timetable', 'The exam timetable for this semester is now available.', '2023-10-07 16:00:00', '2023-10-24'),
(12, 'Grade 8 Carnation', 'Important Announcement 1', 'This is the content for announcement 1.', '2023-10-07 16:00:00', '2023-10-15'),
(13, 'Grade 8 Rose', 'Upcoming Event', 'Details about the event happening next week.', '2023-10-07 16:00:00', '2023-10-20'),
(14, 'Grade 8 Chamomile', 'School News', 'Latest news about school activities.', '2023-10-07 16:00:00', '2023-10-15'),
(15, 'Grade 8 Daisy', 'Reminder: Parent-Teacher Meeting', 'Don\'t forget the meeting on October 12th.', '2023-10-07 16:00:00', '2023-10-13'),
(16, 'Grade 8 Carnation', 'Important Announcement 2', 'This is the content for announcement 2.', '2023-10-07 16:00:00', '2023-10-15'),
(17, 'Grade 8 Rose', 'Science Fair', 'Details about the upcoming science fair.', '2023-10-07 16:00:00', '2023-10-17'),
(18, 'Grade 8 Chamomile', 'Art Exhibition', 'Information about the upcoming art exhibition.', '2023-10-07 16:00:00', '2023-10-22'),
(19, 'Grade 8 Daisy', 'Sports Day', 'Get ready for the annual sports day!', '2023-10-07 16:00:00', '2023-10-19'),
(20, 'Grade 8 Carnation', 'Holiday Schedule', 'Check the schedule for the upcoming holidays.', '2023-10-07 16:00:00', '2023-10-12'),
(21, 'Grade 8 Rose', 'Exam Timetable', 'The exam timetable for this semester is now available.', '2023-10-07 16:00:00', '2023-10-24'),
(22, 'Grade 8 Chamomile', 'Book Fair', 'Visit the book fair happening in the school library.', '2023-10-07 16:00:00', '2023-10-18'),
(23, 'Grade 8 Daisy', 'PTA Meeting', 'Parents, join us for the Parent-Teacher Association meeting.', '2023-10-07 16:00:00', '2023-10-16'),
(24, 'Grade 8 Carnation', 'School Picnic', 'Details about the upcoming school picnic.', '2023-10-07 16:00:00', '2023-10-20'),
(25, 'Grade 8 Rose', 'Student Council Elections', 'Get ready to cast your votes for the Student Council elections.', '2023-10-07 16:00:00', '2023-10-21'),
(26, 'Grade 8 Chamomile', 'Career Fair', 'Learn about various career options at the Career Fair.', '2023-10-07 16:00:00', '2023-10-19'),
(27, 'Grade 8 Daisy', 'Art Contest', 'Participate in the school-wide art contest and showcase your talent!', '2023-10-07 16:00:00', '2023-10-22'),
(28, 'Grade 8 Carnation', 'Field Trip Announcement', 'Details about the upcoming field trip for Grade 8 Carnation.', '2023-10-07 16:00:00', '2023-10-14'),
(29, 'Grade 8 Rose', 'End of Semester Party', 'Celebrate the end of the semester with a fun party!', '2023-10-07 16:00:00', '2023-10-23'),
(30, 'Grade 8 Chamomile', 'Math Quiz Competition', 'Test your math skills in the upcoming quiz competition.', '2023-10-07 16:00:00', '2023-10-20'),
(31, 'Grade 8 Daisy', 'Music Recital', 'Enjoy a musical evening at the school music recital event.', '2023-10-07 16:00:00', '2023-10-25'),
(33, 'Grade 10 Aphrodite', 'This is an edited sample', 'using the edit form', '2023-10-11 16:04:52', '2003-11-27'),
(34, 'Grade 10 Aphrodite', 'My Birthday', 'This should not be seen since its past beyond the expiry date', '2023-10-10 13:37:12', '2003-11-27'),
(36, 'Grade 9 Galilei', 'My Grade 9 Section', 'It was a fun year and I made quite a lot of memories ^ _ ^ and yeah it was great', '2023-10-11 16:05:40', '2023-10-11'),
(37, 'All', 'No Classes ', 'We Will Celebrate Our Christmas Holiday 2 Days Earlier.\r\n\r\nNo Classes Starting Dec 15.', '2023-10-10 14:04:26', '2024-01-01'),
(39, 'Grade 9 Galilei', 'My Grade 9 Section', 'It was a fun year and I made quite a lot of memories ^ _ ^', '2023-10-11 15:08:15', '2023-10-11');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `teacherId` varchar(11) NOT NULL,
  `teacherName` varchar(63) NOT NULL,
  `gradeSection` varchar(31) NOT NULL,
  `password` varchar(31) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `teacherId`, `teacherName`, `gradeSection`, `password`) VALUES
(1, '12345678912', 'Renato Dulog', 'admin', '123'),
(2, '22104607123', 'JayClark Batig Nawng', 'Grade 10 Aphrodite', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
